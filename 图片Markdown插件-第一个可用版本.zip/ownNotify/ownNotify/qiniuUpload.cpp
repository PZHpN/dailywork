#include <stdio.h>
#include "qiniuUpload.h"
#include <assert.h>
#include <Wincodec.h>
#include <windows.h>
#include <time.h>  

#define MacBufferSize 1024
#define ERRORCHECK(hr) assert(SUCCEEDED(hr))
#define OUTFORMAT      GUID_ContainerFormatJpeg

WCHAR* PNG2WDP()
{
	char pBuf[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, pBuf);
	char *p = "\\1.jpg";
	strcat(pBuf, p);

	WCHAR szWdpFileName[MAX_PATH];

	memset(szWdpFileName, 0, sizeof(szWdpFileName));

	int w_nlen = MultiByteToWideChar(CP_ACP, 0, pBuf, -1, NULL, 0);

	MultiByteToWideChar(CP_ACP, 0, pBuf, -1, szWdpFileName, w_nlen);
	wprintf(L"ret:%s\n", szWdpFileName);

	//free(ret);


	IWICImagingFactory *piFactory = NULL;

	IWICBitmapEncoder *piEncoder = NULL;

	IWICBitmapFrameEncode *piBitmapFrame = NULL;

	IWICStream *piStream = NULL;

	UINT uiWidth = 0;
	UINT uiHeight = 0;

	ULONG counter = 0;

	CoInitialize(NULL);

	HRESULT hr = CoCreateInstance(
		CLSID_WICImagingFactory,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_IWICImagingFactory,
		(LPVOID*)&piFactory);

	/****************************************************************************************/
	HANDLE hBitmap = ::GetClipboardData(CF_BITMAP);

	if (hBitmap == NULL){
		return 0;
	}
	HANDLE hPal = NULL;
	hPal = GetStockObject(DEFAULT_PALETTE);
	/***************************************************************************************/

	hr = piFactory->CreateStream(&piStream);
	ERRORCHECK(hr);

	hr = piStream->InitializeFromFilename(szWdpFileName, GENERIC_WRITE);
	ERRORCHECK(hr);

	hr = piFactory->CreateEncoder(OUTFORMAT, NULL, &piEncoder);
	ERRORCHECK(hr);

	hr = piEncoder->Initialize(piStream, WICBitmapEncoderNoCache);
	ERRORCHECK(hr);

	hr = piEncoder->CreateNewFrame(&piBitmapFrame, NULL);
	ERRORCHECK(hr);

	hr = piBitmapFrame->Initialize(NULL);
	ERRORCHECK(hr);

	IWICBitmap *pIBitmap = NULL;
	hr = piFactory->CreateBitmapFromHBITMAP((HBITMAP)hBitmap, NULL, WICBitmapUseAlpha, &pIBitmap);
	ERRORCHECK(hr);

	hr = pIBitmap->GetSize(&uiWidth, &uiHeight);
	ERRORCHECK(hr);

	hr = piBitmapFrame->SetSize(uiWidth, uiHeight);
	ERRORCHECK(hr);

	WICRect rcLock = { 0, 0, uiWidth, uiHeight };

	WICPixelFormatGUID formatGUID = GUID_WICPixelFormat32bppBGRA;
	hr = piBitmapFrame->SetPixelFormat(&formatGUID);
	ERRORCHECK(hr);

	hr = piBitmapFrame->WriteSource(pIBitmap, &rcLock);
	ERRORCHECK(hr);

	hr = piBitmapFrame->Commit();
	ERRORCHECK(hr);

	hr = piEncoder->Commit();
	ERRORCHECK(hr);

	if (pIBitmap){
		pIBitmap->Release();
	}

	if (piFactory){
		counter = piFactory->Release();
	}

	if (piBitmapFrame){
		counter = piBitmapFrame->Release();
	}

	if (piEncoder){
		counter = piEncoder->Release();
	}

	if (piStream){
		counter = piStream->Release();
	}

	CoUninitialize();
	return szWdpFileName;
}

int getFilePath(char *filepath){

	char chInput[512];
	memset(chInput, 0, 512);

	::OpenClipboard(0);

	if (IsClipboardFormatAvailable(CF_BITMAP)){

		sprintf(chInput, "CF_BITMAP is availbale!\n");
		OutputDebugString(chInput);

		WCHAR *Wfilepath = PNG2WDP();

		int w_nlen = WideCharToMultiByte(CP_ACP, 0, Wfilepath, -1, NULL, 0, NULL, false);
		WideCharToMultiByte(CP_ACP, 0, Wfilepath, -1, filepath, w_nlen, NULL, false);

	}
	else{
		MessageBox(NULL, TEXT("clipû��Ҫ�����ĸ�ʽ"), TEXT("testWindow"), MB_OK);
		::CloseClipboard(); // �رռ�����
		return 0;
	}

	::CloseClipboard(); // �رռ�����
	return 1;
}

void debuginfo(Qiniu_Client* client, Qiniu_Error err)
{
	char chInput[2048];
	sprintf(chInput, "\nerror code: %d, message: %s\n", err.code, err.message);
	OutputDebugString(chInput);
	sprintf(chInput, "response header:\n%s", Qiniu_Buffer_CStr(&client->respHeader));
	OutputDebugString(chInput);
	sprintf(chInput, "response body:\n%s", Qiniu_Buffer_CStr(&client->b));
	OutputDebugString(chInput);
	sprintf(chInput, "\n\n\n");
	OutputDebugString(chInput);
	
}
/*�õ��ϴ��ļ���token*/
char* upLoadToken(const char* bucket, Qiniu_Mac* mac)
{
	Qiniu_RS_PutPolicy putPolicy;
	Qiniu_Zero(putPolicy);
	putPolicy.scope = bucket;
	return Qiniu_RS_PutPolicy_Token(&putPolicy, mac);
}

QiniuUpload::QiniuUpload(){

	mac.accessKey = "FlG3x1W0Ir8TvWY-MTTfm5sCuK390CtMqya2FBpq";
	mac.secretKey = "2S2S6-Oi7f-ufpXvdNNBhx-qMB00sPu6xlhkzOGP";

	bucketName = "ownblog";

	Qiniu_Servend_Init(-1);
	Qiniu_Client_InitMacAuth(&client, MacBufferSize, &mac);

}

QiniuUpload::~QiniuUpload(){

	Qiniu_Client_Cleanup(&client);
	Qiniu_Servend_Cleanup();
}


void QiniuUpload::UploadFile()
{
	//const char* uploadName = "test5.jpg";

	time_t timep;
	struct tm *p;
	time(&timep);
	p = localtime(&timep); //�˺�����õ�tm�ṹ���ʱ�䣬���Ѿ����й�ʱ��ת��Ϊ����ʱ��  
	
	char uploadName[50];
	memset(uploadName, 0, 50);
	sprintf(uploadName, "%d-%d-%d-%d-%d-%d.jpg", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);

	/*�õ�uploadKey*/
	const char* uploadtoken = upLoadToken(bucketName, &mac);

	char filepath[MAX_PATH];
	memset(filepath, 0, MAX_PATH);

	if (getFilePath(filepath) == 0){
		return;
	};

	OutputDebugString(filepath);
	
	Qiniu_Io_PutRet putRet;
	Qiniu_Error error = Qiniu_Io_PutFile(&client, &putRet, uploadtoken, uploadName, filepath, NULL);
	
	char chInput[1024];
	memset(chInput, 0, 1024);
	if (error.code != 200)
	{
		sprintf(chInput, "Upload File %s To %s:%s failed.\n", filepath, bucketName, uploadName);
		OutputDebugString(chInput);
		
		debuginfo(&client, error);
		MessageBox(NULL, TEXT("Upload Error"), TEXT("Error"), MB_OK);
	}
	else
	{
		sprintf(chInput, "Upload File %s To %s:%s success.\n", filepath, bucketName, uploadName);
		OutputDebugString(chInput);
		MessageBox(NULL, TEXT("Upload Succ"), TEXT("Succ"), MB_OK);

		char urlname[1024];
		memset(urlname, 0, 1024);
		sprintf(urlname, "![Alt text](http://ou5bv1r9n.bkt.clouddn.com/%s)", uploadName);

		if (::OpenClipboard(0))
		{
			if (::EmptyClipboard())//��ռ�����������  
			{
				int nSize = strlen(urlname) + 1;//�������ֽ�����UNICODE����ÿ���ַ�ռ2���ֽڣ��������һ��\0��β��.

				HGLOBAL hMem = ::GlobalAlloc(GHND, nSize);
				char* pData = (char*)::GlobalLock(hMem);
				//memcpy_s(pData, nSize, ch_Input_file, nSize - 1);
				strcpy(pData, urlname);
				//pData[nSize - 1] = '\0';
				::GlobalUnlock(hMem);
				::SetClipboardData(CF_TEXT, hMem);
				::CloseClipboard();
				::GlobalFree(hMem);
			}
		}
	}
	
	Qiniu_Free((char*)uploadtoken);
}

