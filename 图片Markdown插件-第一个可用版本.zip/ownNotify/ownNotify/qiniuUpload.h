#pragma once

#include <Windows.h>
#include "io.h"
#include "resumable_io.h"
#include "rs.h"

#include "base.h"

class QiniuUpload{
public:
	QiniuUpload();
	~QiniuUpload();

	void QiniuUpload::UploadFile();

private:
	Qiniu_Client client;
	Qiniu_Mac    mac;
	char* bucketName;
};